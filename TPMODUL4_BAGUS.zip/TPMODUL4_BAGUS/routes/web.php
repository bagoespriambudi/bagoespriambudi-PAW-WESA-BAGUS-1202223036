<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

Route::get('/', function () {
    return view('welcome');
});

// 1. Tambahkan route untuk menampilkan daftar pengguna


// 2. Tambahkan route untuk menampilkan form tambah pengguna


// 3. Tambahkan route untuk menyimpan pengguna baru


// 4. Tambahkan route untuk menampilkan form edit pengguna


// 5. Tambahkan route untuk menyimpan perubahan pengguna


// 6. Tambahkan route untuk menghapus pengguna
